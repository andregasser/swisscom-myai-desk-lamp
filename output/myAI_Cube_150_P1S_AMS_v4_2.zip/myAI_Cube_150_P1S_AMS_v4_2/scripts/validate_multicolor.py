"""Check current AMS meshes, assignment, sliced layers and print-bed bounds."""
from pathlib import Path
import argparse
from collections import defaultdict
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import numpy as np
import trimesh
from validate_raster_test import validate as validate_raster
from validate_raster_coverage import analyze as analyze_coverage

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--allow-withheld-raster', action='store_true',
                    help='Audit archived/withheld raster files without approving them for printing')
args = parser.parse_args()

ROOT = Path(__file__).resolve().parents[1]
P = json.loads((ROOT / 'cad/multicolor_parameters.json').read_text())
OUT = ROOT / 'output' / P['output_folder']


def crosses_window(start, end, xmin, ymin, xmax, ymax):
    """Clip an extrusion segment; long white infill can cross with both ends outside."""
    lo, hi = 0., 1.
    for a, b, low, high in zip(start, end, (xmin,ymin), (xmax,ymax)):
        delta=b-a
        if abs(delta) < 1e-9:
            if not low < a < high:
                return False
        else:
            t0,t1=sorted(((low-a)/delta,(high-a)/delta))
            lo,hi=max(lo,t0),min(hi,t1)
    return (hi-lo)*np.linalg.norm(np.subtract(end,start)) > .2


report = {'physical_print_verified': False, 'stl': {}, 'plates': {}}
assert len(list((OUT / 'stl').glob('*.stl'))) == 10
assert {p.stem for p in (OUT / 'print').glob('*.3mf')} == {
    '01_color_test_P1S', '02_panel_P1S', '03_frame_P1S', '04_base_P1S', '05_lid_P1S', '06_feet_P1S', '07_fit_P1S', '08_transmission_test_P1S', '09_raster_test_P1S', '10_raster_original_test_P1S'}
for file in sorted((OUT / 'stl').glob('*.stl')):
    mesh = trimesh.load_mesh(file)
    assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume > 0, file
    assert np.all(mesh.extents <= [256, 256, 250]), file
    assert abs(mesh.bounds[0, 2]) < .001, file
    report['stl'][file.name] = {'watertight': True, 'size_mm': mesh.extents.tolist(),
                               'components': len(mesh.split())}

for file in sorted((OUT / 'print').glob('*.3mf')):
    multi = file.name.startswith(('01_', '02_', '08_', '09_', '10_'))
    transmission = file.name.startswith('08_')
    original = file.name.startswith('10_')
    window_layers = defaultdict(lambda: defaultdict(set))
    if transmission:
        card = json.loads((OUT/'transmission_test/geometry_validation.json').read_text())
        test_meshes=list((OUT/'transmission_test/stl').glob('*.stl'))
        assert {p.name for p in test_meshes} == {f'slot_{i}.stl' for i in range(1,5)}
        for stl in test_meshes:
            mesh=trimesh.load_mesh(stl)
            assert mesh.is_watertight and mesh.is_winding_consistent
    with zipfile.ZipFile(file) as archive:
        assert archive.testzip() is None
        config = json.loads(archive.read('Metadata/project_settings.config'))
        assert config['printer_model'] == 'Bambu Lab P1S'
        assert config['nozzle_diameter'] == ['0.4']
        assert config['filament_type'] == ['PLA'] * (4 if multi else 1)
        assert config['curr_bed_type'] == 'Textured PEI Plate'
        assert config['enable_support'] == '0'
        assert config['sparse_infill_density'] == '100%'
        assert config['wall_generator'] == ('classic' if original else 'arachne')
        if multi:
            assert config['nozzle_temperature'][2] == '210'
            assert config['nozzle_temperature_initial_layer'][2] == '210'
        if multi:
            assert config['filament_colour'] == [c['hex'] for c in P['colors']]
            assert config['enable_prime_tower'] == '1'
            assert config['flush_into_infill'] == '0'
            settings = ET.fromstring(archive.read('Metadata/model_settings.config'))
            parts = settings.findall('object/part')
            assert len(parts) == 4
            for slot, part in enumerate(parts, 1):
                meta = {e.get('key'): e.get('value') for e in part.findall('metadata')}
                assert meta['extruder'] == str(slot)
                assert meta['source_volume_id'] == str(slot - 1)
                assert meta['name'] == P['colors'][slot - 1]['name']
                assert all(int(v) == 0 for k, v in part.find('mesh_stat').attrib.items() if k != 'face_count')
        raw = archive.read('Metadata/plate_1.gcode')
        assert hashlib.md5(raw).hexdigest().lower() == archive.read('Metadata/plate_1.gcode.md5').decode().strip().lower()
        code = raw.decode()
        assert 'machine: P1S' in code and 'G28' in code and 'M83' in code
        assert 'FEATURE: Support' not in code
        feature, tool, changing = 'Custom', 0, False
        x = y = z = 0.
        points, layers = [], defaultdict(set)
        for line in code.splitlines():
            ams = re.match(r'M620 S(\d+)', line)
            if ams:
                tool, changing = int(ams[1]), True
            if line.startswith('M621 '):
                changing = False
            if line.startswith('; FEATURE: '):
                feature = line.removeprefix('; FEATURE: ')
            if not re.match(r'^G[0123] ', line):
                continue
            fields = {k: float(v) for k, v in re.findall(r'\b([XYZE])(-?\d*\.?\d+)', line)}
            previous_xy=(x,y)
            x, y, z = fields.get('X', x), fields.get('Y', y), fields.get('Z', z)
            if feature == 'Custom' or changing or fields.get('E', 0) <= 0 or not ('X' in fields or 'Y' in fields):
                continue
            assert 0 <= x <= 256 and 0 <= y <= 256 and 0 <= z <= 250, (file.name, line)
            assert not (x < 18.25 and y < 28.25), (file.name, 'bed exclusion', line)
            points.append((x, y, z))
            if feature not in ('Prime tower', 'Brim'):
                layers[round(z, 3)].add(tool + 1)
                if transmission:
                    for index, window in enumerate(card['windows']):
                        wx=window['x_mm']+card['print_offset_mm'][0]
                        wy=window['y_mm']+card['print_offset_mm'][1]
                        if crosses_window(previous_xy,(x,y),wx+2,wy+2,wx+22,wy+22):
                            window_layers[index][round(z,3)].add(tool+1)
        assert len(points) > 100
        if multi:
            color_depth = .4 if transmission else P['color_depth_mm']
            if original:
                assert dict(layers) == {.2: {1}, .4: {1}, .6: {1,2,3,4}}, layers
                assert config['additional_cooling_fan_speed'] == ['0']*4
                assert config['fan_max_speed'] == ['50']*4
                assert config['close_fan_the_first_x_layers'] == ['2']*4
                assert config['top_surface_speed'] == ['25','25']
                assert config['seam_gap'] == '0%'
                assert config['detect_thin_wall'] == '1'
                assert config['top_surface_line_width'] == '0.4'
            else:
                assert all(slots == ({1,2,3,4} if z <= color_depth+.001 else {1})
                           for z,slots in layers.items()), layers
            height = card['size_mm'][2] if transmission else P['rail_anchor_mm'] + 2 if file.name.startswith('02_') else P['panel_thickness_mm']
            count = round(height / .2)
            assert set(layers) == {round(i*.2, 1) for i in range(1, count+1)}, layers
        if transmission:
            for index, window in enumerate(card['windows']):
                expected={z: {window['slot'] if z <= window['color_depth_mm']+.001 else 1}
                          for z in (.2,.4,.6)}
                assert dict(window_layers[index]) == expected, (index,window_layers[index],expected)
        result = json.loads(file.with_name(file.stem.replace('_P1S', '_slicer_result') + '.json').read_text())
        assert result['return_code'] == 0
        plate = result['sliced_plates'][0]
        assert not plate['warning_message']
        assert plate['filament_change_times'] == (6 if transmission else 3 if original else 4 if multi else 0)
        report['plates'][file.name] = {
            'sliced_successfully': True, 'bambu_studio': '02.08.02.61',
            'estimated_minutes': round(plate['total_predication'] / 60, 1),
            'estimated_filament_g_including_flush_and_tower': round(sum(f['total_used_g'] for f in plate['filaments']), 2),
            'color_changes': plate['filament_change_times'],
            'print_extrusion_bounds_mm': [np.min(points, axis=0).tolist(), np.max(points, axis=0).tolist()],
            'model_layer_slots': {str(z): sorted(slots) for z, slots in layers.items()} if multi else 'white only',
            'slicer_print_warnings': plate['warning_message'], 'supports_generated': False,
            'gcode_md5_valid': True, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
        }
        if transmission:
            report['plates'][file.name]['all_eight_window_layer_assignments_verified'] = True
            report['plates'][file.name]['window_layer_slots'] = [
                {**window, 'sliced_layers': {str(z): sorted(slots) for z,slots in window_layers[i].items()}}
                for i,window in enumerate(card['windows'])]
        if original:
            report['plates'][file.name]['raster_toolpaths'] = validate_raster(file, original=True)
            coverage = analyze_coverage(file, 'raster_original_test', .6,
                                        OUT/'raster_original_test/surface_coverage')
            report['plates'][file.name]['surface_coverage'] = coverage
            report['raster_print_release_allowed'] = coverage['digital_coverage_passed']
        if file.name.startswith('09_'):
            assert config['initial_layer_line_width'] == '0.4'
            assert config['elefant_foot_compensation'] == '0'
            report['plates'][file.name]['raster_toolpaths'] = validate_raster(file)
(OUT / 'print_validation.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT/'print/RASTER_STATUS.md').write_text(
    '# Status der Rasterprobe 10\n\n'
    + ('Die digitale Flächenprüfung ist bestanden; ein physischer Probedruck bleibt erforderlich.\n\n'
       if report['raster_print_release_allowed'] else
       '**Experimenteller Entwurf: Die vollständige Flächenprüfung ist nicht bestanden.** '
       'Es bleiben rechnerische Lücken in der Farbfläche. Diese Datei ist keine bestätigte '
       'Behebung der weißen Stellen und noch nicht auf die Lampenseiten zu übertragen.\n\n')
    + '[Prüfbericht](../raster_original_test/surface_coverage.json) · '
      '[Versuchsaufbau und Grenzen](../../../docs/RASTERPROBE.md).\n')
print(json.dumps(report['plates'], indent=2))
if not report['raster_print_release_allowed'] and not args.allow_withheld_raster:
    raise SystemExit('Rasterprobe 10: Flächendeckung ungenügend. Keine Freigabe als geschlossene Farbfläche. '
                     'Zum reinen Bestandsaudit --allow-withheld-raster verwenden.')
